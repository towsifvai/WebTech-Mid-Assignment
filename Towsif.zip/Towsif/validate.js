function validateForm(event) {

event.preventDefault();

const form= document.getElementById("employeeForm");    
const id=document.getElementById("employeeId");
const name= document.getElementById("employeeName");
const email= document.getElementById("employeeEmail");    
const date=document.getElementById("employeeJoin");
const department= document.getElementById("department");
const gender= document.getElementById("employeeGender");    
const type=document.getElementById("employeeType");


const errorid=document.getElementById("IdError");
const errorname= document.getElementById("NameError");
const erroremail= document.getElementById("EmailError");    
const errordate=document.getElementById("DateError");
const errordepartment= document.getElementById("DepartmentError");
const errorgender= document.getElementById("GenderError");    
const errortype=document.getElementById("CheckboxError");




function validateName() {
  const regex = /^[a-zA-Z\s]{3,}$/;
  if (!regex.test(name.value.trim())) {
    errorname.style.display = 'inline';
    return false;
  }
  errorname.style.display = 'none';
  return true;
  }


  function validateID()
  {
const regex = /^(?=.*[A-Z])(?=.*\d)[A-Z0-9]{3,}$/;
if(!regex.test(id.value.trim()))
{
errorid.style.display='inline';
return false;
}
errorid.style.display='none';
return true;
}



function validateEmail(){

const regex= /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/ ;
if (!regex.test(email.value.trim())) {
  {
    erroremail.style.display= 'inline';
    return false;
  }
erroremail.style.display='none';
return true;
}

}




function validateDepartment(){

if (department.value===""){

  errordepartment.style.display='inline';
  return false;
}
errordepartment.style.display='false';
return true;

}




  
  
  
  
  
  
  
  //returnig all the validation functions
const nameValid= validateName();
const idValid= validateID();
const emailValid=validateEmail();



if (nameValid && idValid && emailValid) {
  form.submit(); // Now submit the form manually
}
}

